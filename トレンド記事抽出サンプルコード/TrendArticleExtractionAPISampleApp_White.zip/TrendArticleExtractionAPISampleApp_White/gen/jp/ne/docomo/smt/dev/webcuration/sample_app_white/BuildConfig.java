/** Automatically generated file. DO NOT MODIFY */
package jp.ne.docomo.smt.dev.webcuration.sample_app_white;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}